-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 26, 2015 at 11:19 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--
CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library`;

-- --------------------------------------------------------

--
-- Table structure for table `authors_books_t`
--

CREATE TABLE IF NOT EXISTS `authors_books_t` (
  `id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `authors_t`
--

CREATE TABLE IF NOT EXISTS `authors_t` (
  `id` int(11) NOT NULL,
  `author_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books_t`
--

CREATE TABLE IF NOT EXISTS `books_t` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `checkouts_t`
--

CREATE TABLE IF NOT EXISTS `checkouts_t` (
  `id` int(11) NOT NULL,
  `due_date` date DEFAULT NULL,
  `copy_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `checkin_status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies_t`
--

CREATE TABLE IF NOT EXISTS `copies_t` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patrons_t`
--

CREATE TABLE IF NOT EXISTS `patrons_t` (
  `id` int(11) NOT NULL,
  `patron_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors_books_t`
--
ALTER TABLE `authors_books_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `authors_t`
--
ALTER TABLE `authors_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books_t`
--
ALTER TABLE `books_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkouts_t`
--
ALTER TABLE `checkouts_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `copy_id` (`copy_id`),
  ADD KEY `patron_id` (`patron_id`);

--
-- Indexes for table `copies_t`
--
ALTER TABLE `copies_t`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `patrons_t`
--
ALTER TABLE `patrons_t`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors_books_t`
--
ALTER TABLE `authors_books_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `authors_t`
--
ALTER TABLE `authors_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `books_t`
--
ALTER TABLE `books_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `checkouts_t`
--
ALTER TABLE `checkouts_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `copies_t`
--
ALTER TABLE `copies_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `patrons_t`
--
ALTER TABLE `patrons_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `authors_books_t`
--
ALTER TABLE `authors_books_t`
  ADD CONSTRAINT `authors_books_t_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors_t` (`id`),
  ADD CONSTRAINT `authors_books_t_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `authors_t` (`id`),
  ADD CONSTRAINT `authors_books_t_ibfk_3` FOREIGN KEY (`book_id`) REFERENCES `books_t` (`id`);

--
-- Constraints for table `checkouts_t`
--
ALTER TABLE `checkouts_t`
  ADD CONSTRAINT `checkouts_t_ibfk_1` FOREIGN KEY (`copy_id`) REFERENCES `copies_t` (`id`),
  ADD CONSTRAINT `checkouts_t_ibfk_2` FOREIGN KEY (`patron_id`) REFERENCES `patrons_t` (`id`);

--
-- Constraints for table `copies_t`
--
ALTER TABLE `copies_t`
  ADD CONSTRAINT `copies_t_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books_t` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
